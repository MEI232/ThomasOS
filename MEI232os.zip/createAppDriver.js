function editId(id, changeTo){
  document.getElementById(id).innerHTML = changeTo;
}